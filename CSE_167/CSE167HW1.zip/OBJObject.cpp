#include "OBJObject.h"

OBJObject::OBJObject(const char *filepath) 
{
	toWorld = glm::mat4(1.0f);
	parse(filepath);
    this->angle = 0.0f;
    rmx = glm::mat4(1.0f);
    tmx = glm::mat4(1.0f);
    position = glm::vec3(0.0f);
    size = glm::vec3(1.0f);
}

void OBJObject::parse(const char *filepath) 
{
	//TODO parse the OBJ file
	// Populate the face indices, vertices, and normals vectors with the OBJ Object data
    FILE* fp;
    float x, y, z;
    float r, g, b;
    int c1, c2;
    
    fp = fopen(filepath, "rb");
    
    while((c1 = fgetc(fp)) != EOF) {
        if(c1 == 'v') {
            c2 = fgetc(fp);
            if(c2 == ' ') {
                fscanf(fp, "%f %f %f %f %f %f", &x, &y, &z, &r, &g, &b);
                vertices.push_back(glm::vec3(x, y, z));
            }
            else if(c2 == 'n') {
                fscanf(fp, "%f, %f, %f", &x, &y, &z);
                normals.push_back(glm::vec3(x, y, z));
            }
        }
        if(feof(fp)) break;
    }

    fclose(fp);
}
    
void OBJObject::draw() 
{
	glMatrixMode(GL_MODELVIEW);
	// Push a save state onto the matrix stack, and multiply in the toWorld matrix
	glPushMatrix();
	glMultMatrixf(&(toWorld[0][0]));
    glBegin(GL_POINTS);
	// Loop through all the vertices of this OBJ Object and render them
    for (unsigned int i = 0; i < vertices.size(); ++i)
    {
        glm::vec3 normalized = normalize(normals[i]) * 0.5f + 0.5f;
        glColor3f(normalized.x, normalized.y, normalized.z);
        glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
    }
        
	glEnd();
    
	// Pop the save state off the matrix stack
	// This will undo the multiply we did earlier
	glPopMatrix();
    toWorld = glm::mat4(1.0f);
}
void OBJObject::update(glm::vec3 vec)
{
    spin(1.0f, vec);
    this->toWorld = tmx * rmx * smx * this->toWorld;
}

void OBJObject::spin(float deg, glm::vec3 vec)
{
    this->angle += deg;
    if (this->angle > 360.0f || this->angle < -360.0f) this->angle = 0.0f;
    this->rmx = glm::rotate(glm::mat4(1.0f), this->angle / 180.0f * glm::pi<float>(), vec);
}

void OBJObject::translate(glm::vec3 vec) {
    this->position += vec;
    this->tmx = glm::translate(glm::mat4(1.0f), this->position);
}

void OBJObject::scale(glm::vec3 vec) {
    this->size *= vec;
    this->smx = glm::scale(glm::mat4(1.0f), this->size);
}

void OBJObject::resetPos(glm::vec3 vec) {
    this->position = vec;
    translate(glm::vec3(0.0f));
}

void OBJObject::resetOriScale() {
    this->size = glm::vec3(1.0f);
    scale(glm::vec3(2.0f));
    this->angle = 0.0f;
}

glm::mat4 OBJObject::getWorld() {
    return this->toWorld;
}

std::vector<glm::vec3> OBJObject::getVertices() {
    return this->vertices;
}

std::vector<glm::vec3> OBJObject::getNormals() {
    return this->normals;
}

void OBJObject::resetToWorld() {
    this->toWorld = glm::mat4(1.0f);
}


